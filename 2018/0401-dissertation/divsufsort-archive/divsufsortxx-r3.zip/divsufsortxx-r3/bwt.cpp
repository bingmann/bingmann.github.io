/*
 * bwttest.cpp
 * Copyright (c) 2003-2008 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "divsufsortxx.h"
#include "divsufsortxx_utility.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>

int
main(int argc, const char *argv[]) {
  FILE *fp;
  unsigned char *T;
  int *A;
  int n, pidx;
  clock_t start, finish;

  if(argc != 3) { ::fprintf(stderr, "usage: %s INFILE OUTFILE\n", argv[0]); return 1; }

  /* Open a file for reading */
  if((fp = ::fopen(argv[1], "rb")) == NULL) {
    ::fprintf(stderr, "%s: Cannot open file `%s': ", argv[0], argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  ::fseek(fp, 0, SEEK_END);
  n = ::ftell(fp);
  ::rewind(fp);

  /* Allocate 5n bytes of memory */
  T = NULL, A = NULL;
  try {
    T = new unsigned char[n]; if(T == NULL) { throw; }
    A = new int[n]; if(A == NULL) { throw; }
  } catch(...) {
    ::fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    ::exit(EXIT_FAILURE);
  }

  /* Read n bytes of data */
  if(::fread(T, sizeof(unsigned char), n, fp) != (size_t)n) {
    ::fprintf(stderr, "%s: %s `%s': ",
      argv[0],
      (::ferror(fp) || !::feof(fp)) ? "Cannot read from" : "Unexpected EOF in",
      argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  ::fclose(fp);

  /* Construct the BWTed string */
  ::fprintf(stderr, "%s: %d bytes ... ", argv[1], n);
  start = ::clock();
  pidx = divsufsortxx::constructBWT(T, T + n, T, T + n, A, A + n, 256);
  finish = ::clock();
  if(pidx < 0) {
    ::fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    ::exit(EXIT_FAILURE);
  }
  ::fprintf(stderr, "%.4f sec\n", (double)(finish - start) / (double)CLOCKS_PER_SEC);

  /* Write 4 + n bytes of data */
  if((fp = ::fopen(argv[2], "wb")) == NULL) {
    ::fprintf(stderr, "%s: Cannot open file `%s': ", argv[0], argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  unsigned char P[4] = {pidx & 0xff, (pidx >> 8) & 0xff, (pidx >> 16) & 0xff, (pidx >> 24) & 0xff};
  if((::fwrite(P, sizeof(unsigned char), 4, fp) != 4) ||
     (::fwrite(T, sizeof(unsigned char), n, fp) != (size_t)n)) {
    ::fprintf(stderr, "%s: Cannot write to `%s': ", argv[0], argv[2]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  ::fclose(fp);

  /* Deallocate memory */
  delete [] A;
  delete [] T;

  return 0;
}
