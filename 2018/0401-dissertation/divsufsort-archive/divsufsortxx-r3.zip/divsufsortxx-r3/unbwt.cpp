/*
 * unbwt.cpp
 * Copyright (c) 2003-2008 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "divsufsortxx.h"
#include "divsufsortxx_utility.h"
#include <cstdio>
#include <cstdlib>
#include <ctime>

int
main(int argc, const char *argv[]) {
  FILE *fp;
  unsigned char *T;
  int n, pidx;
  int err;
  clock_t start, finish;

  if(argc != 3) { ::fprintf(stderr, "usage: %s INFILE OUTFILE\n", argv[0]); return 1; }

  /* Open a file for reading */
  if((fp = ::fopen(argv[1], "rb")) == NULL) {
    ::fprintf(stderr, "%s: Cannot open file `%s': ", argv[0], argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  ::fseek(fp, 0, SEEK_END);
  n = ::ftell(fp) - 4;
  ::rewind(fp);

  /* Allocate 5n bytes of memory */
  T = NULL;
  try {
    T = new unsigned char[n]; if(T == NULL) { throw; }
  } catch(...) {
    ::fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    ::exit(EXIT_FAILURE);
  }

  /* Read 4 + n bytes of data */
  unsigned char P[4];
  if((::fread(P, sizeof(unsigned char), 4, fp) != 4) ||
     (::fread(T, sizeof(unsigned char), n, fp) != (size_t)n)) {
    ::fprintf(stderr, "%s: %s `%s': ",
      argv[0],
      (::ferror(fp) || !::feof(fp)) ? "Cannot read from" : "Unexpected EOF in",
      argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  pidx = P[0] | (P[1] << 8) | (P[2] << 16) | (P[3] << 24);
  ::fclose(fp);

  /* Reconstruct the original string */
  ::fprintf(stderr, "%s: %d bytes ... ", argv[1], n);
  start = ::clock();
  err = divsufsortxx::reverseBWT_psi(T, T + n, pidx, 256); // 5n, normal
//  err = divsufsortxx::reverseBWT_lf(T, T + n, pidx, 256); // 6n, fast?
//  err = divsufsortxx::reverseBWT_tlf(T, T + n, pidx, 256); // 5n, very fast, n is limited to 2^23 or 2^24
//  err = divsufsortxx::reverseBWT_clf(T, T + n, pidx, 256); // 3.625n, slow, small space
  finish = ::clock();
  if(err != 0) {
    if(err == -2) {
      ::fprintf(stderr, "%s: Cannot allocate memory.\n", argv[0]);
    } else {
      ::fprintf(stderr, "%s: Invalid data.\n", argv[0]);
    }
    ::exit(EXIT_FAILURE);
  }
  ::fprintf(stderr, "%.4f sec\n", (double)(finish - start) / (double)CLOCKS_PER_SEC);

   /* Write n bytes of data */
  if((fp = ::fopen(argv[2], "wb")) == NULL) {
    ::fprintf(stderr, "%s: Cannot open file `%s': ", argv[0], argv[1]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  if(::fwrite(T, sizeof(unsigned char), n, fp) != (size_t)n) {
    ::fprintf(stderr, "%s: Cannot write to `%s': ", argv[0], argv[2]);
    ::perror(NULL);
    ::exit(EXIT_FAILURE);
  }
  ::fclose(fp);

  /* Deallocate memory */
  delete [] T;

  return 0;
}
