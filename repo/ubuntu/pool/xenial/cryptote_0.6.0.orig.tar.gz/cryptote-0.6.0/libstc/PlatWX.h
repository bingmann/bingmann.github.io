
namespace Scintilla {

wxRect wxRectFromPRectangle(Scintilla::PRectangle prc);
Scintilla::PRectangle PRectangleFromwxRect(wxRect rc);
wxColour wxColourFromCA(const Scintilla::ColourAllocated& ca);

} // namespace Scintilla
