/////////////////////////////////////////////////////////////////////////////
// Name:        wx/grid.h
// Purpose:     wxGrid base header
// Author:      Julian Smart
// Modified by:
// Created:
// Copyright:   (c) Julian Smart
// RCS-ID:      $Id: grid.h 33948 2005-05-04 18:57:50Z JS $
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_GRID_H_BASE_
#define _WX_GRID_H_BASE_

#include "wx/generic/grid.h"

#endif
    // _WX_GRID_H_BASE_
