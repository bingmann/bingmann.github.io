#!/bin/bash

./run-scan.sh | tee -a scan-$HOSTNAME.txt
./run-random.sh | tee -a random-$HOSTNAME.txt
