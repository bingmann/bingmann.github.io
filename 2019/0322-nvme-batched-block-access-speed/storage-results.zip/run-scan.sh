#!/bin/bash

FOXXLL_TOOL=~/stxxl/build/extlib/foxxll/tools/foxxll_tool

export RESULT=" host=$HOSTNAME"

for((batch_size = 1; batch_size <= 128; batch_size = batch_size * 2)); do
    for((block_size = 1; block_size <= 65536; block_size = block_size * 2)); do

        time ${FOXXLL_TOOL} benchmark_disks -q -T 10 16GiB w -b ${batch_size} -B ${block_size}KiB
        time ${FOXXLL_TOOL} benchmark_disks -q -T 10 16GiB r -b ${batch_size} -B ${block_size}KiB

    done
done
