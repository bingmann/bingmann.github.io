#!/bin/bash

FOXXLL_TOOL=~/stxxl/build/extlib/foxxll/tools/foxxll_tool

export RESULT=" host=$HOSTNAME"

span_size=128GiB
work_size=8GiB
work_size_kib=$((8 * 1024 * 1024))
if [[ $HOSTNAME == "i10pc130" ]]; then
    span_size=16GiB
fi

time ${FOXXLL_TOOL} benchmark_disks_random ${span_size} 2MiB ${work_size} i random_cyclic

for((block_size = 1; block_size <= 65536; block_size = block_size * 2)); do
    for((batch_size = block_size; batch_size <= $work_size_kib; batch_size = batch_size * 2)); do

        if [[ $HOSTNAME == "i10pc130" ]]; then
            # for rotational: do 2048 accesses
            work_size=$((block_size * 2048))KiB
        fi
        if [[ $HOSTNAME == "i10pc129" ]]; then
            # for rotational: do 524288 accesses
            work_size=$((block_size * 524288))KiB
        fi

        time ${FOXXLL_TOOL} benchmark_disks_random ${span_size} ${block_size}KiB ${work_size} w random_cyclic --batch_size ${batch_size}KiB
        time ${FOXXLL_TOOL} benchmark_disks_random ${span_size} ${block_size}KiB ${work_size} r random_cyclic --batch_size ${batch_size}KiB
        done
done
