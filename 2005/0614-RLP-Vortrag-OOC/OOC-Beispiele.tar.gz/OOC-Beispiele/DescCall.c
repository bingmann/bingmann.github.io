/* DescCall.c */

#include "Descriptor.h"

int main() {

     Descriptor *f = (Descriptor*)stdfile_open("datei.txt","w");
     f->write(f,"test",4);
     f->close(f);

     return 0;
}
