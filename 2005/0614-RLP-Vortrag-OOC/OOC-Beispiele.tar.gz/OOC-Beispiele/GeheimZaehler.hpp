/* GeheimZaehler.hpp */

#include <time.h>

class GeheimZaehler {
private:
     long zahl;
     time_t mtime;
     long max;
     
     void touch();
public:
     GeheimZaehler(long startwert);

     long get_zahl();
     void set_zahl(long wert);
};
