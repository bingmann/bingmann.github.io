/* GeheimZaehler.c */

#include "GeheimZaehler.h"

#include <time.h>
#include <stdlib.h>

struct _GeheimZaehler {
     long zahl;
     time_t mtime;
     long max;
};

static void geheimzaehler_touch(GeheimZaehler *this) {
     this->mtime = time(NULL);
}

GeheimZaehler* geheimzaehler_create(long startwert) {
     GeheimZaehler* n = malloc(sizeof *n);
     n->zahl = n->max = startwert;
     geheimzaehler_touch(n);
     return n;
}

long geheimzaehler_get_zahl(GeheimZaehler *this) {
     return this->zahl;
}
void geheimzaehler_set_zahl(GeheimZaehler *this, long wert) {
     this->zahl = wert;
     if (this->max < wert) this->max = wert;
     geheimzaehler_touch(this);
}
