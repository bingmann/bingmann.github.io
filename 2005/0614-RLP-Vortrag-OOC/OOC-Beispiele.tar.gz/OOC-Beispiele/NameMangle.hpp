
#ifndef NameMangle_H
#define NameMangle_H

struct Point
{
	float x;
	float y;
};

namespace Graph
{
	class Test
	{
	public:
		float get_x(Point* p, int i);
	};
} 

void set_x(Point* p,int i);


#endif
