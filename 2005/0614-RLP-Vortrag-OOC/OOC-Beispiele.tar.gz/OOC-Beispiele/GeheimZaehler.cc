/* GeheimZaehler.cc */

#include "GeheimZaehler.hpp"

GeheimZaehler::GeheimZaehler(long startwert) {
     zahl = max = startwert;
     touch();
}

void GeheimZaehler::touch() {
     mtime = time(NULL);
}

long GeheimZaehler::get_zahl() {
     return zahl;
}
void GeheimZaehler::set_zahl(long wert) {
     zahl = wert;
     if (max < zahl) max = zahl;
     touch();
}
