
#ifndef RTTI_H
#define RTTI_H

#include <stdio.h>

class Shape
{
public:
	virtual void Test(){printf("Shape\n");}
};

class Rectangle : public Shape
{
public:
	void Test(){printf("Rectangle\n");}
};

class Circle : public Shape
{
public:
	void Test(){printf("Circle\n");}
};

class Box : public Shape
{
public:
	void Test(){printf("Box\n");}
};



#endif 
