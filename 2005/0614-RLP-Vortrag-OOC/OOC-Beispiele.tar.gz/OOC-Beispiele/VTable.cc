/* VTable.cc */

#include <stdio.h>

class Uni {
private:
     long long c;
public:
     Uni() {
	  c = 0x00C0FFEE0000BABEll;
     }
     virtual int get() {
	  return 42;
     }
     virtual void set(long long v) {
	  c = v;
     }
};

class Earth : public Uni {
public:
     virtual const char *get_letters() {
	  return "What is 6 times 9?";
     }
};

int main() {
     Uni uni;
     Earth earth;

     fwrite(&uni, sizeof(uni), 1, stdout);
     fputs("\xAA\xAA\xAA\xAA", stdout);
     fwrite(&earth, sizeof(earth), 1, stdout);
}

/*
./VTable | hexdump
0000000 87e0 0804 babe 0000 ffee 00c0 aaaa aaaa
0000010 87c8 0804 babe 0000 ffee 00c0          

objdump -s VTable
Contents of section .rodata:
 80487a0 03000000 01000200 aaaaaaaa 00576861  .............Wha
 80487b0 74206973 20362074 696d6573 20393f00  t is 6 times 9?.
 80487c0 00000000 f0870408 4a860408 54860408  ........J...T...
 80487d0 78860408 00000000 00000000 e8870408  x...............
 80487e0 4a860408 54860408 b8990408 03880408  J...T...........
 80487f0 88990408 fc870408 e8870408 35456172  ............5Ear
 8048800 74680033 556e6900                    th.3Uni.        




*/
