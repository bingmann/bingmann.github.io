/* Descriptor.h */

typedef struct _Descriptor Descriptor;

struct _Descriptor {
     int (*read)(Descriptor *this, void* b, int ml);
     int (*write)(Descriptor *this, const void *b, int l);
     int (*close)(Descriptor *this);
};

/* opaque objects */
typedef struct _StdFile StdFile;
typedef struct _SocketPair SocketPair;
typedef struct _TCPv4Socket TCPv4Socket;

/* constructor prototypes */
StdFile* stdfile_open(const char *path, const char* mode);
SocketPair* socketpair_create(void);
TCPv4Socket* tcpv4socket_connect(const char *host, int port);

/* object methods */
int descriptor_puts(Descriptor *this, const char *string);
SocketPair* socketpair_getother(SocketPair *this);
unsigned long tcpv4socket_getpeername(TCPv4Socket *this);
