/* GeheimZaehler.h */

typedef struct _GeheimZaehler GeheimZaehler;

GeheimZaehler* geheimzaehler_create(long startwert);         /* Konstruktor */

long geheimzaehler_get_zahl(GeheimZaehler *this);            /* Methoden */
void geheimzaehler_set_zahl(GeheimZaehler *this, long wert);
