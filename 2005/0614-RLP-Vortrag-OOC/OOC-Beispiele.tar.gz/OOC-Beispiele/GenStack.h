/* GenStack.h */

#define DefineGenStack(T)                               \
                                                        \
struct GenStack_##T {                                   \
     int top, len;                                      \
     T *data;                                           \
};                                                      \
typedef struct GenStack_##T GenStack_##T;               \
                                                        \
static inline GenStack_##T *stack_##T##_create() {      \
     GenStack_##T *n = malloc(sizeof *n);               \
     n->top = n->len = 0;                               \
     n->data = NULL;                                    \
     return n;                                          \
}                                                       \
static inline                                           \
void stack_##T##_push(GenStack_##T *s, T e) {           \
     if (s->top+1 > s->len) {                           \
        s->len += 32;                                   \
        s->data = realloc(s->data, s->len * sizeof(T)); \
     }                                                  \
     s->data[s->top++] = e;                             \
}                                                       \
static inline T stack_##T##_pop(GenStack_##T *s) {      \
     if (s->top > 0) return s->data[--s->top];          \
     return 0;                                          \
}
