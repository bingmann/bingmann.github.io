
#include "NameMangle.hpp"

using namespace Graph;
	
float Test::get_x(Point* p, int i)
{
	return p[i].x;
}

void set_x(Point* p,int i)
{
	p[i].x = 5;
}
