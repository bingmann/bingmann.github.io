/* GeheimZaehler1.h */

struct GeheimZaehler {
     long zahl;
     time_t mtime;
     long max;
};

GeheimZaehler* geheimzaehler_create(long startwert);           /* Konstruktor */

long geheimzaehler_get_zahl(GeheimZaehler *this);              /* Methoden */
void geheimzaehler_set_zahl(GeheimZaehler *this, long wert);
