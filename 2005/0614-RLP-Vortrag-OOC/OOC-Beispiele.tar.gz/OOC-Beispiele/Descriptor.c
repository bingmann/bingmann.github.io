/* Descriptor.c */

#include "Descriptor.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int descriptor_puts(Descriptor *this, const char *string) {
     return this->write(this, string, strlen(string));
}

struct _StdFile {
     int (*read)(StdFile *this, void* b, int ml);
     int (*write)(StdFile *this, void *b, int l);
     int (*close)(StdFile *this);
     FILE *fp;
};

static int stdfile_read(StdFile *this, void *buffer, int maxlen) {
     return fread(buffer, maxlen, 1, this->fp);
}
static int stdfile_write(StdFile *this, void *buffer, int len) {
     return fwrite(buffer, len, 1, this->fp);
}
static int stdfile_close(StdFile *this) {
     fclose(this->fp);
     free(this);
     return 1;
}

StdFile* stdfile_open(const char *path, const char* mode) {
     StdFile *n;
     FILE *fp = fopen(path, mode);
     if (fp == NULL) return NULL;
     n = malloc(sizeof *n);
     n->read = stdfile_read;
     n->write = stdfile_write;
     n->close = stdfile_close;
     n->fp = fp;
     return n;
}

#include <unistd.h>

typedef struct _StreamSocket {
     Descriptor super;
     int fd;
} StreamSocket;

static int streamsocket_read(StreamSocket *this, void *buffer, int maxlen) {
     return read(this->fd, buffer, maxlen);
}
static int streamsocket_write(StreamSocket *this, void *buffer, int len) {
     return write(this->fd, buffer, len);
}
static int streamsocket_close(StreamSocket *this) {
     return close(this->fd);
}

static void streamsocket_create(StreamSocket *this) {
     this->super.read = (int (*)(Descriptor*,void*,int))streamsocket_read;
     this->super.write = (int (*)(Descriptor*,const void*,int))streamsocket_write;
     this->super.close = (int (*)(Descriptor*))streamsocket_close;
}

struct _SocketPair {
     int (*read)(StreamSocket *this, void* b, int ml);
     int (*write)(StreamSocket *this,void *b, int l);
     int (*close)(StreamSocket *this);
     int fd;
     struct _SocketPair *other;
};

#include <sys/types.h>
#include <sys/socket.h>

SocketPair* socketpair_create(void) {
     SocketPair *n1 = malloc(sizeof *n1);
     SocketPair *n2 = malloc(sizeof *n2);
     int fds[2];

     socketpair(AF_UNIX, SOCK_STREAM, 0, fds);

     streamsocket_create((StreamSocket*)n1);
     streamsocket_create((StreamSocket*)n2);

     n1->fd = fds[0]; n1->other = n2;
     n2->fd = fds[1]; n2->other = n1;
     return n1;
}

SocketPair* socketpair_getother(SocketPair *this) {
     return this->other;
}

struct _TCPv4Socket {
     int (*read)(StreamSocket *this, void* b, int ml);
     int (*write)(StreamSocket *this,void *b, int l);
     int (*close)(StreamSocket *this);
     int fd;
};

#include <netdb.h>

TCPv4Socket* tcpv4socket_connect(const char *host, int port) {
     TCPv4Socket *n = malloc(sizeof *n);

     streamsocket_create((StreamSocket*)n);
     n->fd = socket(AF_INET, SOCK_STREAM, 6);
     if (n->fd < 0) { free(n); return NULL; }

     { /* build connection */
	  struct hostent *he;
	  struct sockaddr_in sa;
	  int r;

	  he = gethostbyname(host);
	  if (!he) { free(n); return NULL; }
	  
	  sa.sin_family = AF_INET;
	  sa.sin_addr.s_addr = *(unsigned long*)he->h_addr;
	  sa.sin_port = htons(port);
	  
	  r = connect(n->fd, (struct sockaddr*)&sa, sizeof(sa));
	  if (r != 0) { free(n); return NULL; }
     }
     return n;
}

unsigned long tcpv4socket_getpeername(TCPv4Socket *this) {
     struct sockaddr_in sa;
     int salen = sizeof(sa);

     int r = getpeername(this->fd, (struct sockaddr*)&sa, &salen);
     if (r != 0) return 0;
     return (unsigned long)sa.sin_addr.s_addr;     
}
