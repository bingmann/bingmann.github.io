 
#include "RTTI.hpp"

#include <stdio.h>
#include <typeinfo>


void printID(Shape* sp)
{
	if (typeid(*sp)==typeid(Rectangle)) printf("Es ist ein Rectangle\n"); 
	else if (typeid(*sp)==typeid(Circle)) printf("Es ist ein Circle\n"); 
	else printf("Ja, was ist es denn...?\n"); 
}

int main()
{
	Rectangle r; 
	Shape *sp=&r; 
	printID(sp);
	
	Circle c;
	sp = &c;
	printID(sp);
	
	Box b;
	sp = &b;
	printID(sp);
	
	printf("%s\n",typeid(r).name());
	
	return 0;
}
