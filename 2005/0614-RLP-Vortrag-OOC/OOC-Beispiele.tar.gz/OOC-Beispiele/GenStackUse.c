/* GenStackUse.cc */

#include <stdio.h>
#include <stdlib.h>

#include "GenStack.h"

DefineGenStack(double);

int main() {

     GenStack_double *s = stack_double_create();

     stack_double_push(s, 100.0);
     stack_double_push(s, 42.0);

     printf("%g\n", stack_double_pop(s));
     printf("%g\n", stack_double_pop(s));
     return 0;
}
